package Entities;

public enum TerminalPrintType {
	Information, Error, Warning, Debug
}
