package Entities;

public enum MessageType {

    CheckIn, CheckOut,

}
