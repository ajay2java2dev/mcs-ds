package entities;

public enum MenuItemType {

	APPETIZER, SALAD, BEEF, PORK, CHICKEN, SEAFOOD, SOUP, OTHER,
}
