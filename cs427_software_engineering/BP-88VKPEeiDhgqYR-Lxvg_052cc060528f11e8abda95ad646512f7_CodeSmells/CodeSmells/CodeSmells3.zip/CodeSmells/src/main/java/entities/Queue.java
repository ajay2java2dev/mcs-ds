package entities;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public abstract class Queue<T> {

	BlockingQueue<T> blockQueue;

	public Queue(int size) {
		blockQueue = new ArrayBlockingQueue<T>(size);
	}

	public boolean put(T item) {
		try {
			blockQueue.put(item);
			return true;
		} catch (InterruptedException e) {
			return false;
		}
	}

	public T take() {
		try {
			return blockQueue.take();
		} catch (InterruptedException e) {
			return null;
		}
	}

}
