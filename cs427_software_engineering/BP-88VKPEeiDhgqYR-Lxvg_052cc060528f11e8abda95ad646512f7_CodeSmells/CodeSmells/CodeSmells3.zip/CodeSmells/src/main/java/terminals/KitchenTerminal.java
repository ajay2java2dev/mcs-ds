package terminals;

import components.OrderQueue;
import components.ServingQueue;
import entities.Order;
import entities.Serving;

public class KitchenTerminal extends Terminal {

	KitchenTerminal() {
		super();
	}

	public Order getOrder() {
		OrderQueue oq = OrderQueue.getInstance();
		return oq.take();
	}

	public void serveOrder(Serving serving) {
		ServingQueue sq = ServingQueue.getInstance();
		sq.put(serving);
	}

}
