package entities;

public enum MessageType {
	CHECKIN, CHECKOUT
}
