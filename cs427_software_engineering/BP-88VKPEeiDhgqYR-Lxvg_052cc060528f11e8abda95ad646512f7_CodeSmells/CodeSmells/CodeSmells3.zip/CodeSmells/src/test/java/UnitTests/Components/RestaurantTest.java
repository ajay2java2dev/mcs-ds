package UnitTests.Components;

import org.junit.Test;

import components.Restaurant;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class RestaurantTest {

    @Test
    public void createClearRestaurantTest(){
//        assertEquals(null, Restaurant.getInstance());
//        Restaurant q = Restaurant.getOrCreateInstance(10);
//        assertNotEquals(null, Restaurant.getInstance());
//        Restaurant.clearInstance();
//        assertEquals(null, Restaurant.getInstance());
    }
}
