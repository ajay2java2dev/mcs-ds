package Entities;

public enum MessageType {

    CHECKIN, CHECKOUT

}
