package Entities;

public enum TerminalPrintType {
    INFORMATION, ERROR, WARNING, DEBUG
}
