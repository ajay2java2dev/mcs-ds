package edu.ncsu.csc326.coffeemaker.exceptions;

public class RecipeException extends Exception {
	
private static final long serialVersionUID = 1L;

	public RecipeException(String msg) {
		super(msg);
	}

}
