package WhiteBox;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class IpValidatorTest {

    @Test
    public void testNegative(){
        IpValidator tool = new IpValidatorImpl();
        assertEquals("Neither",tool.validIPAddress("0"));
        assertEquals("Neither",tool.validIPAddress(".0.0.0"));
        assertEquals("Neither",tool.validIPAddress("1.a.0.0"));

        assertEquals("Neither",tool.validIPAddress("fe80:::383c:ad72:fd0:10b3%16"));
        assertEquals("Neither",tool.validIPAddress("::383c:ad72:fd0:10b3%16"));

        //upper case in ipv6 should fail
        assertEquals("Neither",tool.validIPAddress("2001:0  DB8::85A3:0000:0000:8a2e:0370:7334"));
        assertEquals("Neither",tool.validIPAddress("2001:0@db8::85a3:0000:0000:8a2e:0370:7334"));
        assertEquals("Neither",tool.validIPAddress("2001::FFFF::85a3:0000:0000:8a2e:0370:7334"));
    }

    @Test
    public void testValidPositiveIpAddress () {
        IpValidator tool = new IpValidatorImpl();
        assertEquals("IPv4",tool.validIPAddress("123.0.0.1"));
        assertEquals("IPv6",tool.validIPAddress("2001:0db8:85a3:0000:0000:8a2e:0370:7334"));
    }
}
