package BlackBox;

import BlackBox.Setups.LruCacheSetup;
import Utils.LruCacheMethod;
import org.junit.Test;

public class LruCacheBlackBoxTest extends LruCacheSetup {

    @Test
    public void testPositiveValues(){
        //constructor size = 2
        int[] functionParameters = new int[]{2};
        lruCachePUT.run(LruCacheMethod.Constructor,
                functionParameters,
                null);

        //put key=1, value = 2
        int[] functionParameters2 = new int[]{1,2};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters2,
                null);

        //get key = 1
        int[] functionParameters3 = new int[]{1};
        lruCachePUT.run(LruCacheMethod.Get,
                functionParameters3,
                2);
    }

    @Test
    public void testLargeNumbers(){
        //constructor size = 2
        int[] functionParameters = new int[]{2};
        lruCachePUT.run(LruCacheMethod.Constructor,
                functionParameters,
                null);

        //put key=1, value = 2
        int[] functionParameters2 = new int[]{1,123321,2,0,3,121212,4,1231213,5,121212};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters2,
                null);

        //get key = 1
        int[] functionParameters3 = new int[]{1};
        lruCachePUT.run(LruCacheMethod.Get,
                functionParameters3,123321
                );

        int[] functionParameters4 = new int[]{1,123321,2,0,3,121212,4,1231213,5,121212};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters4,
                null);

        int[] functionParameters5 = new int[]{1};
        lruCachePUT.run(LruCacheMethod.Get,
                functionParameters5,123321
        );
    }

    @Test
    public void testNullRuns(){
        int[] functionParameters = new int[]{-1,1};
        lruCachePUT.run(LruCacheMethod.valueOf("Constructor"),
                functionParameters,null
        );

        lruCachePUT.run(LruCacheMethod.valueOf("Get"),
                functionParameters,-1
        );

        int[] functionParameters5 = new int[]{5,1000};
        lruCachePUT.run(LruCacheMethod.valueOf("Put"),
                functionParameters5,null
        );

        int[] key = new int[]{5};
        lruCachePUT.run(LruCacheMethod.valueOf("Get"),
                key,1000
        );

    }

    @Test
    public void testLruNodes () {

        //constructor size = 2
        int[] functionParameters = new int[]{1};
        lruCachePUT.run(LruCacheMethod.Constructor,
                functionParameters,
                null);

        int[] functionParameters2 = new int[]{1,123321,2,123123,3,121212,4,1231213,5,121212};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters2,
                null);

        int[] functionParameters3 = new int[]{1,123321,2,123321,3,123321,4,1231213,5,121212};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters3,
                null);

        //get key = 1
        int[] functionParameters4 = new int[]{3};
        lruCachePUT.run(LruCacheMethod.Get,
                functionParameters3,123321
        );
    }

    @Test
    public void testLruNegativeNodes () {
        int[] functionParameters = new int[]{'c'};
        lruCachePUT.run(LruCacheMethod.Constructor,
                functionParameters,
                null);

        int[] functionParameters2 = new int[]{1,'c'};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters2,
                null);

        int[] functionParameters3 = new int[]{1};
        lruCachePUT.run(LruCacheMethod.Get,
                functionParameters3,99
        );

        //also
        functionParameters = new int[]{2,1};
        lruCachePUT.run(LruCacheMethod.Constructor,
                functionParameters,
                null);

        functionParameters2 = new int[]{1,2};
        lruCachePUT.run(LruCacheMethod.Put,
                functionParameters2,
                null);
    }
}
