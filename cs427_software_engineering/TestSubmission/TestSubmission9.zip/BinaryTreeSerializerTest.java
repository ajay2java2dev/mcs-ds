package WhiteBox;

import Utils.TreeNode;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class BinaryTreeSerializerTest {

    @Test
    public void serializeTestWithNull(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = null;
        String ret = bs.serialize(root);
        assertEquals("[null]",ret);
    }

    @Test
    public void serializeTestWithObject(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);

        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);

        String ret = bs.serialize(root);
        assertEquals("[5,4,7,3,10,6,8,null,null,null,null,null,null,null,null]",ret);
    }

    @Test
    public void serializeTestWithNodeList(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);
        root.left.right.right = null;
        root.left.right.left = null;


        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);

        String ret = bs.serialize(root);
        assertEquals("[5,4,7,3,10,6,8,null,null,null,null,null,null,null,null]",ret);
    }

    @Test
    public void serializeTestWithNegativeValues(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = new TreeNode(-5);

        root.left = new TreeNode(-4);
        root.left.left = new TreeNode(-3);
        root.left.right = new TreeNode(-10);

        root.right = new TreeNode(-7);
        root.right.left = new TreeNode(-6);
        root.right.right = new TreeNode(-8);
        String ret = bs.serialize(root);
        assertEquals("[-5,-4,-7,-3,-10,-6,-8,null,null,null,null,null,null,null,null]",ret);
    }

    @Test
    public void deserializeWithNull(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[null]";
        TreeNode root = null;
        TreeNode rootret = bs.deserialize(s);
        assertEquals(root,rootret);

        String s1 = "[]";
        TreeNode rootret1 = bs.deserialize(s1);
        assertEquals(root,rootret1);
    }

    @Test
    public void deSerializeTestWithEmpty(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[n,n,n,n]";

        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);

        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);

        TreeNode treeNode = bs.deserialize(s);
        assertNotEquals(root,treeNode);
    }

    @Test
    public void deSerializeTestWithNoPart(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s1 = "[5,n,n,n]";
        String s2 = "[5]";
        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);

        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);

        TreeNode treeNode1 = bs.deserialize(s1);
        assertNotEquals(root,treeNode1);

        TreeNode treeNode2 = bs.deserialize(s2);
        assertNotEquals(root,treeNode2);
    }

    @Test
    public void deSerializeTestWithObject(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[5,4,7,3,10,6,8,null,null,null,null,null,null,null,null]";

        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);

        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);

        TreeNode treeNode = bs.deserialize(s);
        assertEquals(root,treeNode);
    }

    @Test
    public void deSerializeTestWithNegative(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[-5,-4,-7,-3,-10,-6,-8,null,null,null,null,null,null,null,null]";

        TreeNode root = new TreeNode(-5);

        root.left = new TreeNode(-4);
        root.left.left = new TreeNode(-3);
        root.left.right = new TreeNode(-10);

        root.right = new TreeNode(-7);
        root.right.left = new TreeNode(-6);
        root.right.right = new TreeNode(-8);

        TreeNode treeNode = bs.deserialize(s);
        assertEquals(root,treeNode);
    }

    @Test
    public void compareTreeNodes () {
        TreeNode root1 = new TreeNode(-5);
        root1.left = new TreeNode(-4);
        root1.left.left = new TreeNode(-3);
        root1.left.right = new TreeNode(-10);
        root1.right = new TreeNode(-7);
        root1.right.left = new TreeNode(-6);
        root1.right.right = new TreeNode(-8);

        TreeNode root2 = new TreeNode(-5);
        root2.left = new TreeNode(-4);
        root2.left.left = new TreeNode(-3);
        root2.left.right = new TreeNode(-10);
        root2.right = new TreeNode(-7);
        root2.right.left = new TreeNode(-6);
        root2.right.right = new TreeNode(-8);

        assertEquals(true,root1.equals(root2));

        TreeNode root3 = new TreeNode(1);
        TreeNode root4 = new TreeNode(1);
        root3.left = new TreeNode(3);
        root3.left.left = null;
        root3.right = new TreeNode(4);
        root4.left = new TreeNode(3);
        root4.right = new TreeNode(4);
        root4.left.left = null;

        assertEquals(root3.hashCode(),root4.hashCode());
        assertEquals(true,root3.equals(root3));
        assertEquals(true,root3.equals(root4));
        assertEquals(false,root3.equals(new Object()));
        assertEquals(false,root3.equals(null));

        TreeNode root5 = new TreeNode(1);
        TreeNode root6 = new TreeNode(1);
        root5.left = null;
        root6.left = null;
        root5.right = new TreeNode(1);
        root6.right = null;
        assertEquals(false,root5.equals(root6));
    }
}
