package WhiteBox;

import BlackBox.CycleSort;
import Utils.TreeNode;
import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class BinaryTreeSerializerTest {

    @Test
    public void serializeTestWithNull(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = null;
        String ret = bs.serialize(root);
        assertEquals("[null]",ret);
    }

    @Test
    public void serializeTestWithObject(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);

        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);
        String ret = bs.serialize(root);
        assertEquals("[5,4,7,3,10,6,8,null,null,null,null,null,null,null,null]",ret);
    }

    @Test
    public void serializeTestWithNegativeValues(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        TreeNode root = new TreeNode(-5);

        root.left = new TreeNode(-4);
        root.left.left = new TreeNode(-3);
        root.left.right = new TreeNode(-10);

        root.right = new TreeNode(-7);
        root.right.left = new TreeNode(-6);
        root.right.right = new TreeNode(-8);
        String ret = bs.serialize(root);
        assertEquals("[-5,-4,-7,-3,-10,-6,-8,null,null,null,null,null,null,null,null]",ret);
    }

    @Test
    public void deserializeWithNull(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[null]";
        TreeNode root = null;
        TreeNode rootret = bs.deserialize(s);
        assertEquals(root,rootret);
    }

    @Test
    public void derializeTestWithObject(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[5,4,7,3,10,6,8,null,null,null,null,null,null,null,null]";

        TreeNode root = new TreeNode(5);

        root.left = new TreeNode(4);
        root.left.left = new TreeNode(3);
        root.left.right = new TreeNode(10);

        root.right = new TreeNode(7);
        root.right.left = new TreeNode(6);
        root.right.right = new TreeNode(8);

        TreeNode treeNode = bs.deserialize(s);
        assertEquals(root,treeNode);
    }

    @Test
    public void derializeTestWithNegative(){
        BinaryTreeSerializer bs = new BinaryTreeSerializerImpl();
        String s = "[-5,-4,-7,-3,-10,-6,-8,null,null,null,null,null,null,null,null]";

        TreeNode root = new TreeNode(-5);

        root.left = new TreeNode(-4);
        root.left.left = new TreeNode(-3);
        root.left.right = new TreeNode(-10);

        root.right = new TreeNode(-7);
        root.right.left = new TreeNode(-6);
        root.right.right = new TreeNode(-8);

        TreeNode treeNode = bs.deserialize(s);
        assertEquals(root,treeNode);
    }

   
}
