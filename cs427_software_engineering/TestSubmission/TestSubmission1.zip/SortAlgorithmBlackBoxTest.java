package BlackBox;

import BlackBox.Setups.SortSetup;
import org.junit.Test;

public class SortAlgorithmBlackBoxTest extends SortSetup {

    @Test
    public void testPositiveValues(){
        int[] input = new int[]{2,1};
        int[] expectedOutput = new int[]{1,2};
        sortAlgorithmPUT.run(input,expectedOutput);
    }

    @Test
    public void testArrayOfChars () {
        int[] input = new int[]{'u','n','i','v','e','r','s','i','t','y','o','f','i','l','l','i','n','o','i','s'};
        int[] expectedOutput = new int[]{'e','f','i','i','i','i','i','l','l','n','n','o','o','r','s','s','t','u','v',
                'y'};
        sortAlgorithmPUT.run(input,expectedOutput);
    }

    @Test
    public void testNegativeNumbers () {
        int[] input = new int[]{-1,2,4,99999,-99999};
        int[] expectedOutput = new int[]{-99999,-1,2,4,99999};
        sortAlgorithmPUT.run(input,expectedOutput);
    }

    @Test
    public void testMixedValues () {
        int[] input = new int[]{-1,2,4,99999,-99999,'c','b','a'};
        int[] expectedOutput = new int[]{-99999,-1,2,4,'a','b','c',99999};
        sortAlgorithmPUT.run(input,expectedOutput);
    }
}
