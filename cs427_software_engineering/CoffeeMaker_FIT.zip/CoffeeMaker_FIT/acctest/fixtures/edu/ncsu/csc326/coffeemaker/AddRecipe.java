package edu.ncsu.csc326.coffeemaker;

import edu.ncsu.csc326.coffeemaker.exceptions.RecipeException;
import fit.ActionFixture;

public class AddRecipe extends ActionFixture {
	Recipe recipe;
	RecipeBook recipes = new RecipeBook();
	
	/**
	 * This method simulates the user action of pressing
	 * a menu option.
	 * @param option
	 */
	public void menuOption(int option) {
		recipe = new Recipe();
	}

	public void recipeName(String name) {
		recipe.setName(name);
	}

	public void recipePrice(String price) throws RecipeException {
		recipe.setPrice(price);
	}

	public void recipeCoffeeUnits(String coffee) throws RecipeException {
		recipe.setAmtCoffee(coffee);
	}

	public void recipeMilkUnits(String milk) throws RecipeException {
		recipe.setAmtMilk(milk);
	}

	public void recipeSugarUnits(String sugar) throws RecipeException {
		recipe.setAmtSugar(sugar);
	}

	public void recipeChocolateUnits(String chocolate) throws RecipeException  {
		recipe.setAmtChocolate(chocolate);
	}
	
	public boolean addRecipe() {
		return recipes.addRecipe(recipe);
	}
}
