package ComputerExercise;

public interface Computer {
    String run();
    String getDescription();
}
