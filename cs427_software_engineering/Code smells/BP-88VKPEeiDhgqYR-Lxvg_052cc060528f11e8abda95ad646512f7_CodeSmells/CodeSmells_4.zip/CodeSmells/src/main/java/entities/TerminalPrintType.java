package entities;

public enum TerminalPrintType {
    INFORMATION,
    ERROR
}
