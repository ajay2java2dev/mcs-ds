package UnitTests.Components;

import org.junit.Test;

public class RestaurantTest {

    @Test
    public void createClearRestaurantTest() {
//        assertEquals(null, Restaurant.getInstance());
//        Restaurant q = Restaurant.getOrCreateInstance(10);
//        assertNotEquals(null, Restaurant.getInstance());
//        Restaurant.clearInstance();
//        assertEquals(null, Restaurant.getInstance());
    }
}
