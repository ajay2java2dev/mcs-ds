package entities;

public enum MenuItemType {
    BEEF
}
