package entities;

public enum TerminalPrintType {
    INFORMATION,
    ERROR,
    WARNING,
    DEBUG
}
