package BlackBox;

public interface LruCache {

    int get(int key);

    void put(int key, int value);

}
