package Utils;

public enum LruCacheMethod {
    Constructor,
    Get,
    Put
}
