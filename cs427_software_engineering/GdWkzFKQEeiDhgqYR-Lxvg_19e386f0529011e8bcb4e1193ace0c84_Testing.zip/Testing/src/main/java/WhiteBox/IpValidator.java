package WhiteBox;

public interface IpValidator {
    String validIPAddress(String IP);
}
